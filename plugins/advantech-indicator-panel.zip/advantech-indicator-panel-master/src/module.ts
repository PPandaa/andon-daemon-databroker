﻿///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
///<reference path="indicator.d.ts" />
import _ from 'lodash';
import $ from 'jquery';
import './marquee';
import kbn from 'app/core/utils/kbn';
import {MetricsPanelCtrl, loadPluginCss} from 'app/plugins/sdk';
import {reference} from './reference';
import ChangeFont from 'app/core/utils/fontsize';
import TimeSeries from 'app/core/time_series';
import config from 'app/core/config';

System.import('plugins/advantech-indicator-panel/css/default.css' + '!css');
loadPluginCss({
  dark: 'plugins/advantech-indicator-panel/css/dark.css',
  light: 'plugins/advantech-indicator-panel/css/light.css',
});
const defaultColor: any[] = ['#0cc90c', '#ffb700', '#ff231e'];
export const panelDefaults = {
  maxDataPoints: 100,
  currentMode: 'indicators',
  indicatorPosition: 'center',
  trendMode: 'graph',
  adjustableFontSize: true,
  indicatorsHeading: {
    name: '',
    fontSize: '70%',
    color: '#5ac8fa',
  },
  indicatorDivider: false,
  indicatorsConfigs: [
    {
      subtitle: {
        name: 'Subtitle',
        fontSize: '70%',
        color: '#5ac8fa',
      },
      value: {
        selected: '',
        selectedQuery: '',
        selectedCol: '',
        valueName: 'avg',
        fontSize: '130%',
        thresholds: {
          on: false,
          fill: '50, 80',
          type: 'number',
          selected: '',
          selectedQuery: '',
          selectedCol: '',
          display: 'Low, Normal, High',
        },
        format: 'none',
        decimals: '',
        colors: _.cloneDeep(defaultColor),
      },
      valueMaps: [{value: '', text: ''}],
      colorMaps: [{value: '', text: '', type: 'value'}],
      prefix: {
        name: '',
        fontSize: '130%',
        applyValueColor: false,
      },
      postfix: {
        name: '',
        selected: '',
        selectedQuery: '',
        selectedCol: '',
        fontSize: '80%',
        applyValueColor: false,
      },
      target: {
        name: 'Target',
        nameFontSize: '70%',
        nameColor: '#999999',
        fillValue: '',
        selectedValue: '',
        selectedQuery: '',
        selectedCol: '',
        valueFontSize: '70%',
        valueName: 'avg',
        format: 'none',
        decimals: '',
        valueColor: '#999999',
        position: 'right',
        preAndPostfix: {
          prefix: '',
          preFontSize: '70%',
          preColor: '#999999',
          postfix: '',
          postFontSize: '70%',
          postColor: '#999999',
        },
        layout: {},
      },
    },
  ],
  // Trend
  trend: {
    value: '',
    selectedQuery: '',
    selectedCol: '',
    fillThres: '',
    selectedThres: '',
    valueName: 'avg',
    fontSize: '70%',
    format: 'none',
    decimals: '',
    lineColor: '#0cc90c',
    formatX: 'Autoscale',
    divide: 0,
    minValue: 0,
    maxValue: 100,
    gaugeColor: ['#0cc90c', '#ff231e'],
    thresPostfix: '',
    barColor: ['#088f08', '#ffb700'],
    barWidth: 3,
    fillDirection: 'down',
  },
  referMode: 'half',
  referPosition: 'center',
  referScroll: false,
  referenceConfigs: [
    {
      tagHeader: '',
      valueHeader: '',
      position: 'center',
      borderLeft: false,
      headerColor: '#5ac8fa',
      labelColor: '#999999',
      valueColor: '#999999',
      valueName: 'avg',
      format: 'none',
      decimals: '',
      prefix: '',
      postfix: '',
      align: 'right',
      labelFontSize: '70%',
      contentFontSize: '80%',
      sideValSelected: '',
      sideValSelectedQuery: '',
      sideValSelectedCol: '',
      sideLabel: '',
      sideFontSize: '80%',
      sideColor: '#999999',
      sidePosition: 'flex-end',
      tbody: [
        {
          label: '',
          selected: '',
        },
      ],
      tbodyTable: {
        selectedQuery: '',
        selectedLabelCol: '',
        selectedValueCol: '',
      },
    },
  ],
};
class PaneCtrl extends MetricsPanelCtrl {
  static templateUrl = 'partials/module.html';
  modeOptions: any = [
    {label: 'indicators', value: 'indicators'},
    // { label: 'abnormal', value: 'abnormal' },
    {label: 'indicators + trend', value: 'indicators + trend'},
    {label: 'indicators + reference value', value: 'reference'},
    {label: 'reference value', value: 'referenceOnly'},
  ];
  colors: any = [
    '#0cc90c',
    '#ffb700',
    '#ff231e',
    'rgba(45, 91, 172, 0.9)',
    'rgba(247, 243, 27, 0.9)',
    'rgba(184, 27, 247, 0.9)',
  ];
  valueNameOptions: any[] = [
    {value: 'min', text: 'Min'},
    {value: 'max', text: 'Max'},
    {value: 'avg', text: 'Average'},
    {value: 'current', text: 'Current'},
    {value: 'total', text: 'Total'},
    {value: 'name', text: 'Name'},
    {value: 'first', text: 'First'},
    {value: 'delta', text: 'Delta'},
    {value: 'diff', text: 'Difference'},
    {value: 'range', text: 'Range'},
    {value: 'last_time', text: 'Time of last point'},
  ];
  trendMode: any[] = ['graph', 'gauge', 'bar'];
  fontSizes: any[] = ChangeFont.defaultValues;
  unitFormats: any[] = kbn.getUnitFormats();
  activeIndicatorIndex: any = 0;
  activeReferenceIndex: any = 0;
  activeRowIndex: any = 0;
  dataType: any;
  data: any[];
  series: any[];
  selectedOpt: any[];
  canClearSelectOpt: any[];
  trendData: {};
  panelContainer: any;
  dateFormats: any = [
    'Autoscale',
    'yyyy/MM/dd HH:mm',
    'yyyy/MM/dd',
    'yyyy/MM',
    'yyyy',
    'MM/dd HH:mm:ss',
    'MM/dd HH:mm',
    'MM/dd HH',
    'MM/dd',
    'MM',
    'HH:mm:ss',
    'HH:mm',
    'HH',
  ];
  invalidGaugeRange = false;
  tbodyData: any[];
  selectedQuery: any[];
  selectColumns: any[];
  tableData: any[];
  canClearselectedQuery: any[];
  canClearselectColumns: any[];
  canClearThresColumns: any[];
  canClearTargetColumns: any[];
  selectTrendColumns: any[];
  selectedTableColumns: any[];
  sideValSelectedColumns: any[];
  indicatorPosition = [
    {label: 'left', value: 'flex-start'},
    {label: 'center', value: 'center'},
    {label: 'right', value: 'flex-end'},
  ];

  /** @ngInject */
  constructor($scope, $injector, private annotationsSrv) {
    super($scope, $injector);
    _.defaults(this.panel, panelDefaults);
    if (this.scope.$$listeners.isWisePaas) {
      this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
      this.events.on('data-received', this.onDataReceived.bind(this));
      this.events.on('data-error', this.onDataError.bind(this));
      this.events.on('data-snapshot-load', this.onDataReceived.bind(this));
      // this.events.on('init-panel-actions', this.onInitPanelActions.bind(this));
    }
    // compatity
    this.compatibleProcessing();
  }

  /* Processing refactoring the previous version */
  compatibleProcessing() {
    if (this.panel.indicatorsConfigs.length > 0) {
      this.panel.indicatorsConfigs.forEach(indicator => {
        if (!indicator.target.position) {
          indicator.target.position = 'right';
        }
        if (!indicator.value.selectedQuery) {
          indicator.value.selectedQuery = '';
        }
        if (!indicator.value.selectedCol) {
          indicator.value.selectedCol = '';
        }
        if (!indicator.value.thresholds.selectedQuery) {
          indicator.value.thresholds.selectedQuery = '';
        }
        if (!indicator.value.thresholds.selectedCol) {
          indicator.value.thresholds.selectedCol = '';
        }
        if (!indicator.postfix.selectedQuery) {
          indicator.postfix.selectedQuery = '';
        }
        if (!indicator.postfix.selectedCol) {
          indicator.value.thresholds.selectedCol = '';
        }
        if (!indicator.target.selectedQuery) {
          indicator.target.selectedQuery = '';
        }
        if (!indicator.target.selectedCol) {
          indicator.target.selectedCol = '';
        }
      });
    }
    if (!this.panel.hasOwnProperty('indicatorPosition')) {
      this.panel.indicatorPosition = 'center';
    }
    if (!this.panel.trend.hasOwnProperty('divide')) {
      this.panel.trend['divide'] = 0;
    }
    if (!this.panel.trend.hasOwnProperty('fillDirection')) {
      this.panel.trend['fillDirection'] = 'down';
    }
    if (!this.panel.trend.hasOwnProperty('selectedQuery')) {
      this.panel.trend['selectedQuery'] = '';
    }
    if (!this.panel.trend.hasOwnProperty('selectedCol')) {
      this.panel.trend['selectedCol'] = '';
    }
    if (this.panel.referenceConfigs.length > 0) {
      this.panel.referenceConfigs.forEach(rconfig => {
        if (!rconfig.hasOwnProperty('tbodyTable')) {
          rconfig['tbodyTable'] = {
            selectedQuery: '',
            selectedLabelCol: '',
            selectedValueCol: '',
          };
        }
        if (!rconfig.hasOwnProperty('sideValSelectedQuery')) {
          rconfig['sideValSelectedQuery'] = '';
        }
        if (!rconfig.hasOwnProperty('sideValSelectedCol')) {
          rconfig['sideValSelectedCol'] = '';
        }
      });
    }
  }

  onInitEditMode() {
    this.addEditorTab(
      'Options',
      'public/plugins/advantech-indicator-panel/partials/editor.html',
      2
    );
    this.addEditorTab('Reference', reference, 3);
  }

  onInitPanelActions(actions) {
    actions.push({text: 'Export CSV', click: 'ctrl.exportCsv()'});
  }

  issueQueries(datasource) {
    if (this.panel.transform === 'annotations') {
      this.setTimeQueryStart();
      return this.annotationsSrv
        .getAnnotations({
          dashboard: this.dashboard,
          panel: this.panel,
          range: this.range,
        })
        .then(annotations => {
          return {data: annotations};
        });
    }

    return super.issueQueries(datasource);
  }

  onDataError(err) {
    this.render();
  }

  onDataReceived(dataList) {
    if (dataList.length === 0) {
      this.data = [];
    }
    if (dataList.length > 0 && (dataList[0].type === 'table' || dataList[0].columns)) {
      this.dataType = 'table';
      // this.data = dataList;
      this.selectedQuery = [];
      this.selectColumns = [];
      this.tableData = dataList.map(this.tableHandler.bind(this));
      this.setTableValues(this.tableData);
    } else if (dataList.length > 0 && dataList[0].target) {
      this.dataType = 'timeseries';
      //this.data = dataList;
      this.selectedOpt = [];
      this.canClearSelectOpt = [];
      this.series = dataList.map(this.seriesHandler.bind(this));
      this.canClearSelectOpt.unshift('');
      this.setValues();
      this.onFillThresChange();
    }

    this.annotationsSrv
      .getAnnotations({
        dashboard: this.dashboard,
        panel: this.panel,
        range: this.range,
      })
      .then(
        (result: any) => {
          //this.alertState = result.alertState;
          this.render();
        },
        () => {
          this.loading = false;
          this.render();
        }
      );
  }

  setTableValues(tableData) {
    const {indicatorsConfigs} = this.panel;
    if (tableData && tableData.length > 0 && tableData[0].length > 0) {
      this.data = [];
      // select query
      this.selectedQuery = this.panel.targets.map(target => {
        return target.refId;
      });
      this.canClearselectedQuery = this.panel.targets.map(target => {
        return target.refId;
      });
      this.canClearselectedQuery.unshift('');
      if (indicatorsConfigs && indicatorsConfigs.length > 0) {
        indicatorsConfigs.forEach((ic, i) => {
          const valueConf = ic.value;
          const targetConf = ic.target;
          const postfixConf = ic.postfix;
          if (i === this.activeIndicatorIndex && valueConf.selectedQuery !== '') {
            if (this.panel.targets.length > 0) {
              this.panel.targets.forEach((t, i) => {
                if (t.refId && t.refId === valueConf.selectedQuery) {
                  this.selectColumns = Object.keys(this.tableData[i][0]);
                }
              });
            }
          }
          if (
            i === this.activeIndicatorIndex &&
            valueConf.thresholds.selectedQuery !== ''
          ) {
            if (this.panel.targets.length > 0) {
              this.panel.targets.forEach((t, i) => {
                if (t.refId && t.refId === valueConf.thresholds.selectedQuery) {
                  this.canClearThresColumns = Object.keys(this.tableData[i][0]);
                  this.canClearThresColumns.unshift('');
                }
              });
            }
          }
          if (i === this.activeIndicatorIndex && postfixConf.selectedQuery !== '') {
            if (this.panel.targets.length > 0) {
              this.panel.targets.forEach((t, i) => {
                if (t.refId && t.refId === postfixConf.selectedQuery) {
                  this.canClearselectColumns = Object.keys(this.tableData[i][0]);
                  this.canClearselectColumns.unshift('');
                }
              });
            }
          }
          if (i === this.activeIndicatorIndex && targetConf.selectedQuery !== '') {
            if (this.panel.targets.length > 0) {
              this.panel.targets.forEach((t, i) => {
                if (t.refId && t.refId === targetConf.selectedQuery) {
                  this.canClearTargetColumns = Object.keys(this.tableData[i][0]);
                  this.canClearTargetColumns.unshift('');
                }
              });
            }
          }
          // value select
          const data: any = {
            scopedVars: _.extend({}, this.panel.scopedVars),
          };
          if (valueConf.selectedQuery !== '' && valueConf.selectedCol !== '') {
            this.generateTableData(data, valueConf, 'value', undefined);
          }
          // value thres
          if (
            valueConf.thresholds.selectedQuery !== '' &&
            valueConf.thresholds.selectedCol !== ''
          ) {
            this.generateTableData(data, valueConf, 'thresholds', undefined);
          }
          // value postfix
          if (postfixConf.selectedQuery !== '' && postfixConf.selectedCol !== '') {
            this.generateTableData(data, postfixConf, 'postfix', undefined);
          }
          // target select
          if (targetConf.selectedQuery !== '' && targetConf.selectedCol !== '') {
            this.generateTableData(data, targetConf, 'target', undefined);
          }

          this.data.push(data);
        });
      }
      if (this.panel.currentMode === 'indicators + trend') {
        const trendConfig = this.panel.trend;
        if (trendConfig.selectedQuery !== '') {
          if (this.panel.targets.length > 0) {
            this.panel.targets.forEach((t, i) => {
              if (t.refId && t.refId === trendConfig.selectedQuery) {
                this.selectTrendColumns = Object.keys(this.tableData[i][0]);
                this.selectTrendColumns.unshift('');
              }
            });
          }
        }
      }
      if (
        this.panel.currentMode === 'reference' ||
        this.panel.currentMode === 'referenceOnly'
      ) {
        const referenceConfigs = this.panel.referenceConfigs;
        // selectOptions
        referenceConfigs.forEach((rc, i) => {
          const tbody = rc.tbodyTable;
          if (i === this.activeReferenceIndex) {
            if (this.panel.targets.length > 0) {
              this.panel.targets.forEach((t, i) => {
                if (t.refId && t.refId === tbody.selectedQuery) {
                  this.selectedTableColumns = Object.keys(this.tableData[i][0]);
                  this.selectedTableColumns.unshift('');
                }
                if (t.refId && t.refId === rc.sideValSelectedQuery) {
                  this.sideValSelectedColumns = Object.keys(this.tableData[i][0]);
                  this.sideValSelectedColumns.unshift('');
                }
              });
            }
          }
        });
      }
    }
  }

  tableHandler(tableData) {
    const datapoints = [];
    if (tableData.type === 'table') {
      const columnNames = {};
      tableData.columns.forEach((column, columnIndex) => {
        columnNames[columnIndex] = column.text;
      });
      tableData.rows.forEach(row => {
        const datapoint = {};
        row.forEach((value, columnIndex) => {
          const key = columnNames[columnIndex];
          datapoint[key] = value;
        });
        datapoints.push(datapoint);
      });
    }
    return datapoints;
  }

  onSelectedQuery(currentIndex, type) {
    if (this.panel.indicatorsConfigs && this.panel.indicatorsConfigs.length > 0) {
      const currentConfig = this.panel.indicatorsConfigs[currentIndex];
      if (type === 'value') {
        if (currentConfig.value.selectedQuery !== '') {
          this.panel.targets.forEach((t, i) => {
            if (t.refId && t.refId === currentConfig.value.selectedQuery) {
              this.selectColumns = Object.keys(this.tableData[i][0]);
            }
          });
        }
      }
      // if (type === 'thresholds') {
      //   const currentQuery = currentConfig.value.thresholds.selectedQuery;
      //   if (currentQuery !== '') {
      //     this.panel.targets.forEach((t, i) => {
      //       if (t.refId && t.refId === currentQuery) {
      //         this.selectColumns = Object.keys(this.tableData[i][0]);
      //         this.canClearselectColumns = Object.keys(this.tableData[i][0]);
      //         this.canClearselectColumns.unshift("");
      //       }
      //     });
      //   }
      // }
    }
  }

  // generateData
  generateTableData(data, valueConf, type, value) {
    // query column fist
    if (this.panel.targets.length > 0) {
      this.panel.targets.forEach((t, i) => {
        if (type === 'value') {
          if (t.refId && t.refId === valueConf.selectedQuery) {
            data.value = this.tableData[i][0][valueConf.selectedCol];
          }
          const decimalInfo = this.getDecimalsForValue(data.value, valueConf);
          const formatFunc = kbn.valueFormats[valueConf.format];
          data.valueFormatted = formatFunc(
            data.value,
            decimalInfo.decimals,
            decimalInfo.scaledDecimals
          );
          data.valueRounded = kbn.roundValue(data.value, decimalInfo.decimals);
        }
        if (type === 'thresholds') {
          if (
            t.refId &&
            t.refId === valueConf.thresholds.selectedQuery &&
            valueConf.thresholds.selectedCol !== ''
          ) {
            data.thresholdsSelectStr =
              this.tableData[i][0][valueConf.thresholds.selectedCol] + '';
          }
        }
        if (type === 'postfix') {
          if (
            t.refId &&
            t.refId === valueConf.selectedQuery &&
            valueConf.selectedCol !== ''
          ) {
            data.postFixName = this.tableData[i][0][valueConf.selectedCol] + '';
          }
        }
        if (type === 'target') {
          if (
            t.refId &&
            t.refId === valueConf.selectedQuery &&
            valueConf.selectedCol !== ''
          ) {
            data.valueTarget = this.tableData[i][0][valueConf.selectedCol] + '';
            const decimalInfo = this.getDecimalsForValue(data.valueTarget, valueConf);
            const formatFunc = kbn.valueFormats[valueConf.format];
            data.valueFormattedTarget = formatFunc(
              data.valueTarget,
              decimalInfo.decimals,
              decimalInfo.scaledDecimals
            );
            data.valueRoundedTarget = kbn.roundValue(
              data.valueTarget,
              decimalInfo.decimals
            );
          }
        }
        if (type === 'reference') {
          if (t.refId && t.refId === valueConf.tbodyTable.selectedQuery) {
            if (value) {
              data.value = value;
            }
            const decimalInfo = this.getDecimalsForValue(data.value, valueConf);
            const formatFunc = kbn.valueFormats[valueConf.format];
            data.valueFormatted = formatFunc(
              data.value,
              decimalInfo.decimals,
              decimalInfo.scaledDecimals
            );
            data.valueRounded = kbn.roundValue(data.value, decimalInfo.decimals);
          }
        }
        if (type === 'referenceOnly') {
          if (t.refId && t.refId === valueConf.sideValSelectedQuery) {
            if (value) {
              data.value = value;
            }
            const decimalInfo = this.getDecimalsForValue(data.value, valueConf);
            const formatFunc = kbn.valueFormats[valueConf.format];
            data.valueFormatted = formatFunc(
              data.value,
              decimalInfo.decimals,
              decimalInfo.scaledDecimals
            );
            data.valueRounded = kbn.roundValue(data.value, decimalInfo.decimals);
          }
        }
      });
    }
    // data.value = sLine.stats[valueConf.valueName];
    // data.flotpairs = sLine.flotpairs;
    // data.timeStep = sLine.stats.timeStep;
    // data.scopedVars['__name'] = { value: valueConf.selected };
  }

  generateData(data, valueConf, sLine) {
    data.flotpairs = [];
    const lastPoint = _.last(sLine.datapoints);
    const lastValue = _.isArray(lastPoint) ? lastPoint[0] : null;
    if (valueConf.valueName === 'name') {
      data.value = 0;
      data.valueRounded = 0;
      data.valueFormatted = sLine.alias;
    } else if (_.isString(lastValue)) {
      data.value = 0;
      data.valueFormatted = _.escape(lastValue);
      data.valueRounded = 0;
    } else if (valueConf.valueName === 'last_time') {
      const formatFunc = kbn.valueFormats[valueConf.format];
      data.value = lastPoint[1];
      data.valueRounded = data.value;
      data.valueFormatted = formatFunc(data.value, this.dashboard.isTimezoneUtc());
    } else {
      data.value = sLine.stats[valueConf.valueName];
      data.flotpairs = sLine.flotpairs;
      const decimalInfo = this.getDecimalsForValue(data.value, valueConf);
      const formatFunc = kbn.valueFormats[valueConf.format];
      data.valueFormatted = formatFunc(
        data.value,
        decimalInfo.decimals,
        decimalInfo.scaledDecimals
      );
      data.valueRounded = kbn.roundValue(data.value, decimalInfo.decimals);
    }
    data.timeStep = sLine.stats.timeStep;
    data.scopedVars['__name'] = {value: sLine.label};
  }

  generateDataStat(data, valueConf, sLine, type) {
    const flotpairs = [];
    const lastPoint = _.last(sLine.datapoints);
    const lastValue = _.isArray(lastPoint) ? lastPoint[0] : null;
    let value;
    let valueRounded;
    let valueFormatted;
    if (valueConf.valueName === 'name') {
      value = 0;
      valueRounded = 0;
      valueFormatted = sLine.alias;
    } else if (_.isString(lastValue)) {
      value = 0;
      valueFormatted = _.escape(lastValue);
      valueRounded = 0;
    } else if (valueConf.valueName === 'last_time') {
      const formatFunc = kbn.valueFormats[valueConf.format];
      value = lastPoint[1];
      valueRounded = data.value;
      valueFormatted = formatFunc(data.value, this.dashboard.isTimezoneUtc());
    } else {
      value = sLine.stats[valueConf.valueName];
      //flotpairs = sLine.flotpairs;
      const decimalInfo = this.getDecimalsForValue(value, valueConf);
      const formatFunc = kbn.valueFormats[valueConf.format];
      valueFormatted = formatFunc(
        value,
        decimalInfo.decimals,
        decimalInfo.scaledDecimals
      );
      valueRounded = kbn.roundValue(value, decimalInfo.decimals);
    }
    data[type] = valueFormatted;
  }

  setValues() {
    const {indicatorsConfigs} = this.panel;
    this.data = [];
    if (indicatorsConfigs && indicatorsConfigs.length > 0) {
      indicatorsConfigs.forEach(ic => {
        const valueConf = ic.value;
        const targetConf = ic.target;
        const postfixConf = ic.postfix;
        if (this.series && this.series.length > 0) {
          const data: any = {
            scopedVars: _.extend({}, this.panel.scopedVars),
          };
          this.series.forEach(sLine => {
            // value select
            if (valueConf.selected !== '' && valueConf.selected === sLine.alias) {
              data.flotpairs = [];
              const lastPoint = _.last(sLine.datapoints);
              const lastValue = _.isArray(lastPoint) ? lastPoint[0] : null;
              if (valueConf.valueName === 'name') {
                data.value = 0;
                data.valueRounded = 0;
                data.valueFormatted = sLine.alias;
              } else if (_.isString(lastValue)) {
                data.value = 0;
                data.valueFormatted = _.escape(lastValue);
                data.valueRounded = 0;
              } else if (valueConf.valueName === 'last_time') {
                const formatFunc = kbn.valueFormats[valueConf.format];
                data.value = lastPoint[1];
                data.valueRounded = data.value;
                data.valueFormatted = formatFunc(
                  data.value,
                  this.dashboard.isTimezoneUtc()
                );
              } else {
                data.value = sLine.stats[valueConf.valueName];
                data.flotpairs = sLine.flotpairs;
                const decimalInfo = this.getDecimalsForValue(data.value, valueConf);
                const formatFunc = kbn.valueFormats[valueConf.format];
                data.valueFormatted = formatFunc(
                  data.value,
                  decimalInfo.decimals,
                  decimalInfo.scaledDecimals
                );
                data.valueRounded = kbn.roundValue(data.value, decimalInfo.decimals);
              }
              // Add $__name variable for using in prefix or postfix
              data.scopedVars['__name'] = {value: sLine.label};
            }
            // value thres
            if (
              valueConf.thresholds.selected !== '' &&
              valueConf.thresholds.selected === sLine.alias
            ) {
              const flotpairs = [];
              const lastPoint = _.last(sLine.datapoints);
              const lastValue = _.isArray(lastPoint) ? lastPoint[0] : null;
              let value;
              let valueRounded;
              let valueFormatted;
              if (valueConf.valueName === 'name') {
                value = 0;
                valueRounded = 0;
                valueFormatted = sLine.alias;
              } else if (_.isString(lastValue)) {
                value = 0;
                valueFormatted = _.escape(lastValue);
                valueRounded = 0;
              } else if (valueConf.valueName === 'last_time') {
                const formatFunc = kbn.valueFormats[valueConf.format];
                value = lastPoint[1];
                valueRounded = data.value;
                valueFormatted = formatFunc(data.value, this.dashboard.isTimezoneUtc());
              } else {
                value = sLine.stats[valueConf.valueName];
                //flotpairs = sLine.flotpairs;
                const decimalInfo = this.getDecimalsForValue(data.value, valueConf);
                const formatFunc = kbn.valueFormats[valueConf.format];
                valueFormatted = formatFunc(
                  data.value,
                  decimalInfo.decimals,
                  decimalInfo.scaledDecimals
                );
                valueRounded = kbn.roundValue(data.value, decimalInfo.decimals);
              }
              data.thresholdsSelectStr = value + '';
            }
            // target select
            if (
              targetConf.selectedValue !== '' &&
              targetConf.selectedValue === sLine.alias
            ) {
              data.flotpairsTarget = [];
              const lastPoint = _.last(sLine.datapoints);
              const lastValue = _.isArray(lastPoint) ? lastPoint[0] : null;
              if (targetConf.valueName === 'name') {
                data.valueTarget = 0;
                data.valueRoundedTarget = 0;
                data.valueFormattedTarget = sLine.alias;
              } else if (_.isString(lastValue)) {
                data.valueTarget = 0;
                data.valueFormattedTarget = _.escape(lastValue);
                data.valueRoundedTarget = 0;
              } else if (targetConf.valueName === 'last_time') {
                const formatFunc = kbn.valueFormats[targetConf.format];
                data.valueTarget = lastPoint[1];
                data.valueRoundedTarget = data.value;
                data.valueFormattedTarget = formatFunc(
                  data.value,
                  this.dashboard.isTimezoneUtc()
                );
              } else {
                data.valueTarget = sLine.stats[targetConf.valueName];
                data.flotpairsTarget = sLine.flotpairs;
                const decimalInfo = this.getDecimalsForValue(
                  data.valueTarget,
                  targetConf
                );
                const formatFunc = kbn.valueFormats[targetConf.format];
                data.valueFormattedTarget = formatFunc(
                  data.valueTarget,
                  decimalInfo.decimals,
                  decimalInfo.scaledDecimals
                );
                data.valueRoundedTarget = kbn.roundValue(
                  data.valueTarget,
                  decimalInfo.decimals
                );
              }
              // Add $__name variable for using in prefix or postfix
              //data.scopedVars['__name'] = { value: sLine.label };
            }
            if (postfixConf.selected !== '' && postfixConf.selected === sLine.alias) {
              data.postFixName = sLine.datapoints[0][0];
            }
          });
          this.data.push(data);
        }
      });
    }
    //
    if (this.panel.currentMode === 'indicators + trend') {
      if (this.series && this.series.length > 0) {
        const trendConfig = this.panel.trend;
        const trendData: any = {
          scopedVars: _.extend({}, this.panel.scopedVars),
        };
        const trendThresData: any = {
          scopedVars: _.extend({}, this.panel.scopedVars),
        };
        this.series.forEach(sLine => {
          if (trendConfig.value !== '' && trendConfig.value === sLine.alias) {
            // this.trendData
            this.generateData(trendData, trendConfig, sLine);
            this.data['trendData'] = trendData;
          }
          if (
            trendConfig.selectedThres !== '' &&
            trendConfig.selectedThres === sLine.alias
          ) {
            if (Number.isFinite(sLine.datapoints[0][0])) {
              this.generateData(trendThresData, trendConfig, sLine);
              this.data['trendThresData'] = trendThresData;
            } else {
              //"60,80"
              this.data['trendThresData'] = sLine.datapoints;
            }
          }
        });
      }
    }
  }

  getDecimalsForValue(value, conf) {
    if (_.isNumber(conf.decimals)) {
      return {decimals: conf.decimals, scaledDecimals: null};
    }

    const delta = value / 2;
    let dec = -Math.floor(Math.log(delta) / Math.LN10);

    const magn = Math.pow(10, -dec);
    const norm = delta / magn; // norm is between 1.0 and 10.0
    let size;

    if (norm < 1.5) {
      size = 1;
    } else if (norm < 3) {
      size = 2;
      // special case for 2.5, requires an extra decimal
      if (norm > 2.25) {
        size = 2.5;
        ++dec;
      }
    } else if (norm < 7.5) {
      size = 5;
    } else {
      size = 10;
    }

    size *= magn;

    // reduce starting decimals if not needed
    if (Math.floor(value) === value) {
      dec = 0;
    }

    const result: any = {};
    result.decimals = Math.max(0, dec);
    result.scaledDecimals = result.decimals - Math.floor(Math.log(size) / Math.LN10) + 2;

    return result;
  }

  seriesHandler(seriesData) {
    var series = new TimeSeries({
      datapoints: seriesData.datapoints,
      alias: seriesData.target,
    });
    this.selectedOpt.push(seriesData.target);
    this.canClearSelectOpt.push(seriesData.target);
    series.flotpairs = series.getFlotPairs(this.panel.nullPointMode);
    return series;
  }

  setUnitFormat(subItem, type, index) {
    if (type === 'value') {
      this.panel.indicatorsConfigs[index].value.format = subItem.value;
    } else if (type === 'target') {
      this.panel.indicatorsConfigs[index].target.format = subItem.value;
    } else if (type === 'refer') {
      this.panel.referenceConfigs[index].format = subItem.value;
    }
    this.refresh();
  }

  setTrendUnitFormat(subItem) {
    this.panel.trend.format = subItem.value;
    this.refresh();
  }

  addIndicatorsConfig() {
    const config = _.cloneDeep(panelDefaults.indicatorsConfigs[0]);
    this.panel.indicatorsConfigs.push(config);
    this.refresh();
  }

  removeIndicatorsConfig(config) {
    this.panel.indicatorsConfigs = _.without(this.panel.indicatorsConfigs, config);
    this.activeIndicatorIndex = this.panel.indicatorsConfigs.length - 1;
    this.refresh();
  }

  onValueColorChange(panelColorIndex, iconfigIndex) {
    return color => {
      this.panel.indicatorsConfigs[iconfigIndex].value.colors[panelColorIndex] = color;
      this.render();
    };
  }

  invertColorOrder(iconfigIndex) {
    this.invertColor(this.panel.indicatorsConfigs[iconfigIndex].value.colors);
    this.render();
  }

  invertColor(ref) {
    const copy1 = ref[0];
    const copy2 = ref[1];
    const copy3 = ref[2];
    ref[0] = ref[5];
    ref[1] = ref[4];
    ref[2] = ref[3];
    ref[3] = copy3;
    ref[4] = copy2;
    ref[5] = copy1;
  }

  onGaugeColorChange(gaugeColorIndex) {
    return color => {
      this.panel.trend.gaugeColor[gaugeColorIndex] = color;
      this.render();
    };
  }

  onBarColorChange(barColorIndex) {
    return color => {
      this.panel.trend.barColor[barColorIndex] = color;
      this.render();
    };
  }

  getFontSize(fontSize) {
    let mobileApp = '';
    if (this.dashboard && this.dashboard.meta) {
      if (this.dashboard.meta.isPc === false) {
        mobileApp = 'mobile';
      }
    }
    const isVw = this.panel.adjustableFontSize;
    let font = ChangeFont.fontSizeChange(isVw, fontSize, mobileApp);
    // let pxFont = ChangeFont.getFontPx(font);
    return font;
  }

  onTrendModeChange() {
    this.refresh();
  }

  time_format(ticks, min, max, format) {
    switch (format) {
      case 'yyyy/MM/dd HH:mm':
        return '%Y/%m/%d %H:%M';
      case 'yyyy/MM/dd':
        return '%Y/%m/%d';
      case 'yyyy/MM':
        return '%Y/%m';
      case 'yyyy':
        return '%Y';
      case 'MM/dd HH:mm:ss':
        return '%m/%d %H:%M:%S';
      case 'MM/dd HH:mm':
        return '%m/%d %H:%M';
      case 'MM/dd HH':
        return '%m/%d %H';
      case 'MM/dd':
        return '%m/%d';
      case 'MM':
        return '%m';
      case 'HH:mm:ss':
        return '%H:%M:%S';
      case 'HH:mm':
        return '%H:%M';
      case 'HH':
        return '%H';
      default:
        if (min && max && ticks) {
          const range = max - min;
          const secPerTick = range / ticks / 1000;
          // Need have 10 millisecond margin on the day range
          // As sometimes last 24 hour dashboard evaluates to more than 86400000
          const oneDay = 86400010;
          const oneYear = 31536000000;

          if (secPerTick <= 45) {
            return '%H:%M:%S';
          }
          if (secPerTick <= 7200 || range <= oneDay) {
            return '%H:%M';
          }
          if (secPerTick <= 80000) {
            return '%m/%d %H:%M';
          }
          if (secPerTick <= 2419200 || range <= oneYear) {
            return '%m/%d';
          }
          return '%Y-%m';
        }

        return '%H:%M';
    }
  }

  getMinTimeStepOfSeries(data) {
    let min = Number.MAX_VALUE;

    for (let i = 0; i < data.length; i++) {
      if (!data[i].stats.timeStep) {
        continue;
      }

      if (data[i].stats.timeStep < min) {
        min = data[i].stats.timeStep;
      }
    }

    return min;
  }

  onFillThresChange() {
    if (this.panel.trendMode === 'bar') {
      const trendThresData = this.data['trendThresData'];
      if (trendThresData || this.panel.trend.fillThres) {
        let dataArr = [];
        if (trendThresData && this.panel.trend.selectedThres !== '') {
          if (!trendThresData.valueFormatted) {
            dataArr = trendThresData[0][0].split(',').map(strVale => {
              return Number(strVale.trim());
            });
          } else {
            let strValue = trendThresData.value + '';
            dataArr = strValue.split(',').map(strVale => {
              return Number(strVale.trim());
            });
          }
        } else {
          dataArr = this.panel.trend.fillThres.split(',').map(strVale => {
            return Number(strVale.trim());
          });
        }
        if (dataArr.length < this.panel.trend.barColor.length - 1) {
          let count = this.panel.trend.barColor.length - dataArr.length - 1;
          this.panel.trend.barColor.splice(dataArr.length + 1, count);
        } else if (dataArr.length > this.panel.trend.barColor.length - 1) {
          do {
            this.panel.trend.barColor.splice(
              this.panel.trend.barColor.length,
              0,
              'rgb(12,201,21)'
            );
          } while (dataArr.length >= this.panel.trend.barColor.length);
        }
      } else {
        this.panel.trend.barColor = this.panel.trend.barColor.slice(0, 1);
      }
    }
  }

  setSpaceCss(elem) {
    const elemCss = {
      display: 'flex',
      'align-items': 'center',
      'justify-content': 'space-between',
      //'justify-content': 'space-around',
      // 'flex-wrap': 'wrap',
    };
    elem.css(elemCss);
  }

  addColorMap(style) {
    if (!style.colorMaps) {
      style.colorMaps = [];
    }
    style.colorMaps.push({value: '', text: '', type: 'value'});
    this.render();
  }

  removeColorMap(style, index) {
    style.colorMaps.splice(index, 1);
    this.render();
  }

  addValueMap(style) {
    if (!style.valueMaps) {
      style.valueMaps = [];
    }
    style.valueMaps.push({value: '', text: ''});
    this.render();
  }

  removeValueMap(style, index) {
    style.valueMaps.splice(index, 1);
    this.render();
  }

  link(scope, elem, attrs, ctrl: PaneCtrl) {
    const panel = ctrl.panel;
    ctrl.panelContainer = elem.find('.panel-container');
    elem = elem.find('.indicator-panel');
    let data;
    const templateSrv = this.templateSrv;

    function render() {
      const panelHeader = ctrl.panelContainer.find('.panel-header');
      if (!panel.titleBgColor) {
        panelHeader.css({'background-color': 'rgb(70,70,70)'});
      }
      if (!ctrl.series && ctrl.dataType === 'timeseries') {
        return;
      }
      if (!ctrl.tableData && ctrl.dataType === 'table') {
        return;
      }
      data = ctrl.data;
      if (!data) {
        return;
      }
      //const trendPanel = elem.find('.trend-panel');

      if (
        panel.currentMode === 'indicators' ||
        panel.currentMode === 'indicators + trend' ||
        panel.currentMode === 'reference'
      ) {
        getThres();
        setThres();
        const body = getIndicatorsHtml();
        elem.children('.indicatorsBoxFlex').html(body);
        if (panel.currentMode !== 'reference') {
          addBorderRight();
        }
        checkWidthAndHeight();
      }

      if (panel.currentMode === 'indicators + trend') {
        addTrend();
      }
      if (panel.currentMode === 'reference') {
        addReference();
      }
      if (panel.currentMode === 'referenceOnly') {
        addReferenceOnly();
      }
    }

    function addReference() {
      ctrl.setSpaceCss(elem);
      // elem.find('.reference').css('flex', '0 1 50%');
      let boxFlex = elem.find('.indicatorsBoxFlex');
      var splitFlexObj = elem.find('.indicatorSplitFlex');
      // empty
      const referencePanel = elem.find('.reference');
      const isHalf = 'half' === ctrl.panel.referMode;
      referencePanel.css('flex', isHalf ? '1 1 50%' : '3 1');
      boxFlex.css('flex', isHalf ? '1 1 50%' : '1 1');
      if (ctrl.panel.indicatorDivider) {
        boxFlex.addClass('boderRight');
      } else {
        boxFlex.removeClass('boderRight');
      }
      if (splitFlexObj.length === 1) {
        //only one indicator ,left
        splitFlexObj.css('justify-content', 'flex-start');
      } else {
        //more than one
        elem.find('.indicatorsBoxFlex').css('flex', '1');
        // const width = elem.width() - elem.find('.indicatorsBoxFlex').width();
        // // const actualWidth = width * 85 / 100;
        // const height = ctrl.height;
        // referencePanel.width(width).height(height).css('position','relative');
        referencePanel.css('flex', '5');
      }
      addTables(referencePanel);
    }

    function addTables(referencePanel) {
      // 样式
      referencePanel.css('align-items', ctrl.panel.referPosition);
      referencePanel
        .find('.refer-table')
        .css({width: `${Math.ceil(100 / panel.referenceConfigs.length)}%`});
      initReferenceData();
      checkReferBorder(referencePanel);
    }

    function initReferenceData() {
      ctrl.tbodyData = [];
      panel.referenceConfigs.forEach((config, c) => {
        ctrl.tbodyData.push([]);
        if (ctrl.dataType === 'timeseries') {
          config.tbody.forEach((t, i) => {
            ctrl.tbodyData[c].push(Object.assign({}, t));
            if (t.selected !== '') {
              const tableData: any = {
                scopedVars: _.extend({}, ctrl.panel.scopedVars),
              };
              if (ctrl.series.length > 0) {
                ctrl.series.forEach(sLine => {
                  if (t.selected !== '' && t.selected === sLine.alias) {
                    ctrl.generateData(tableData, config, sLine);
                    console.log(tableData);
                    if (tableData.valueFormatted) {
                      ctrl.tbodyData[c][i].value = tableData.valueFormatted;
                      ctrl.tbodyData[c][i].label = sLine.alias;
                    }
                    if (t.label !== '') {
                      ctrl.tbodyData[c][i].label = t.label;
                    }
                  }
                });
              }
            }
            if (config.prefix !== '') {
              ctrl.tbodyData[c][i].prefix = config.prefix;
            }
            if (config.postfix !== '') {
              ctrl.tbodyData[c][i].postfix = config.postfix;
            }
          });
        }
        if (ctrl.dataType === 'table') {
          if (ctrl.panel.targets.length > 0) {
            const tbodyTable = config.tbodyTable;
            ctrl.panel.targets.forEach((t, i) => {
              if (t.refId && t.refId === tbodyTable.selectedQuery) {
                ctrl.tableData[i].forEach((tData, j) => {
                  ctrl.tbodyData[c].push(Object.assign({}, config.tbodyTable));
                  const tableData: any = {
                    scopedVars: _.extend({}, ctrl.panel.scopedVars),
                  };
                  if (tbodyTable.selectedLabelCol !== '') {
                    ctrl.tbodyData[c][j].label = tData[tbodyTable.selectedLabelCol];
                  }
                  if (tbodyTable.selectedValueCol !== '') {
                    const value = tData[tbodyTable.selectedValueCol];
                    ctrl.generateTableData(tableData, config, 'reference', value);
                    ctrl.tbodyData[c][j].value = tableData.valueFormatted;
                    // ctrl.tbody[j].value = tData[tbodyTable.selectedValueCol];
                  }
                  if (config.prefix !== '') {
                    ctrl.tbodyData[c][j].prefix = config.prefix;
                  }
                  if (config.postfix !== '') {
                    ctrl.tbodyData[c][j].postfix = config.postfix;
                  }
                });
              }
              if (t.refId && t.refId === config.sideValSelectedQuery) {
                const siderData: any = {
                  scopedVars: _.extend({}, ctrl.panel.scopedVars),
                };
                if (
                  config.sideValSelectedQuery !== '' &&
                  config.sideValSelectedCol !== ''
                ) {
                  const siderValue = ctrl.tableData[i][0][config.sideValSelectedCol];
                  ctrl.generateTableData(siderData, config, 'referenceOnly', siderValue);
                  ctrl.tbodyData['siderValue'] = siderData.value;
                }
              }
            });
          }
        }
      });
    }

    function checkReferBorder(referencePanel) {
      const referenceHeight = referencePanel.height();
    }

    function getDataBySelected(selected: string, config: any) {
      const data: any = {
        scopedVars: _.extend({}, ctrl.panel.scopedVars),
      };
      if (ctrl.series && ctrl.series.length > 0) {
        ctrl.series.forEach(sLine => {
          if (selected !== '' && selected === sLine.alias) {
            // this.trendData
            ctrl.generateData(data, config, sLine);
          }
        });
      }
      return data;
    }

    function addReferenceOnly() {
      initReferenceData();
      let body = '';
      panel.referenceConfigs.forEach((config, c) => {
        let data;
        if (ctrl.dataType === 'timeseries') {
          data = getDataBySelected(config.sideValSelected, config);
        } else {
          data = ctrl.tbodyData['siderValue'];
        }
        body += `
        <div class="refer-container" style="align-items:${ctrl.panel.referPosition}">
          <div class="refer-content">
            <table class="refer-table">
              <thead class="refer-thead">
                <tr>
                  <td style="color:${config.headerColor};font-size:${ctrl.getFontSize(
          config.labelFontSize
        )}"
                    class="headerTD">${config.tagHeader || ''}</td>
                  <td style="color:${config.headerColor};font-size:${ctrl.getFontSize(
          config.labelFontSize
        )};text-align: ${config.align};"
                    class="headerTD">${config.valueHeader || ''}</td>
                </tr>
              </thead>
              <tbody>
              ${ctrl.tbodyData[c]
                .map(
                  row => `<tr>
                <td class="labelCol" style="color:${
                  config.labelColor
                };font-size:${ctrl.getFontSize(config.contentFontSize)}">
                  ${row.label}
                </td>
                <td class="valueCol" style="color:${
                  config.valueColor
                };font-size:${ctrl.getFontSize(config.contentFontSize)};text-align:${
                    config.align
                  }">
                  ${row.prefix || ''}${row.value}${row.postfix || ''}
                </td>
              </tr>`
                )
                .join('')}
            </tbody>
              </table>
            </div>
            ${
              config.sideLabel && (config.sideValSelected || data)
                ? `<div class="refer-sider borderLeft"
                style="font-size:${ctrl.getFontSize(
                  config.sideFontSize
                )};justify-content:${config.sidePosition};color:${config.sideColor};">
              <div>${config.sideLabel}</div>
              <div>${data.valueFormatted || data}</div>
            </div>`
                : ''
            }
        </div>
        `;
      });
      const refOnlyNode = elem.find('.reference-only');
      refOnlyNode.css('align-items', ctrl.panel.referPosition);
      refOnlyNode.html(body);
      if (ctrl.panel.referScroll) {
        refOnlyNode.find('.refer-content').each((_, item) => {
          ($(item) as any).marquee({
            //duration in milliseconds of the marquee
            duration: 10000,
            //gap in pixels between the tickers
            gap: 30,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'up',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true,
            speed: 50, // 美妙滚动的像素数
            startVisible: true,
            pauseOnHover: true,
          });
        });
      }
    }

    function checkWidthAndHeight() {
      let splitObjs = elem.find('.indicatorSplitFlex');
      let splitObj = splitObjs[0];
      let indicatorValueFlex = elem.find('.indicatorValueFlex');
      let bottomValue = elem.find('.bottomValue');
      let bottomLeftValue = elem.find('.bottomLeftValue');
      let centerSpaceObj = elem.find('.centerSpace');
      let centerValue = elem.find('.centerValue');
      let rightTarget = elem.find('.rightTarget');
      for (let i = 0; i < centerSpaceObj.length; i++) {
        let width =
          splitObj.clientWidth / 100 < 2
            ? '1px'
            : splitObj.clientWidth / 100 < 3 ? '10px' : '25px';
        if (panel.indicatorPosition === 'flex-start') {
          width = splitObj.clientWidth - bottomValue[i].clientWidth - 10 + 'px';
        }
        centerSpaceObj[i].style.width = width;
        console.log(centerSpaceObj[i]);
      }
      for (let i = 0; i < indicatorValueFlex.length; i++) {
        let valueFlexWidth = indicatorValueFlex[i].clientWidth;
        let valueFlexH = indicatorValueFlex[i].clientHeight;
        let splitFlexWidth = splitObjs[i].clientWidth;
        let splitFlexH = splitObjs[i].clientHeight;
        if (valueFlexWidth > splitFlexWidth) {
          splitObjs[i].style['justify-content'] = 'normal';
        }
        if (valueFlexH > splitFlexH + 8) {
          splitObjs[i].style['align-items'] = 'normal';
          if (bottomValue.length > 0) {
            bottomValue[i].style['top'] = '-8px';
            if (panel.currentMode === 'indicators') {
              elem.find('.indicatorsBoxFlex').css('box-sizing', 'content-box');
            }
          }
          if (bottomLeftValue.length > 0) {
            let centerValueH = centerValue[i].clientHeight;
            console.log(centerValueH);
            if (panel.currentMode === 'indicators') {
              if (centerValueH > splitFlexH + 8) {
                bottomLeftValue[i].style['top'] = '-14px';
                rightTarget[i].style['top'] = '-28px';
              }
            } else if (panel.currentMode === 'indicators + trend') {
              if (centerValueH > splitFlexH + 11) {
                bottomLeftValue[i].style['top'] = '-5px';
                rightTarget[i].style['top'] = '-11px';
              } else {
                // splitObjs[i].style['align-items'] = 'center';
              }
            }
          }
        }
      }
    }

    function generateMarkings(trendThresData) {
      let marking;
      if (trendThresData || ctrl.panel.trend.fillThres) {
        let thresArr = [];
        let dataArr = [];
        let item;
        if (ctrl.panel.trend.fillThres !== '') {
          thresArr = ctrl.panel.trend.fillThres.split(',').map(strVale => {
            return Number(strVale.trim());
          });
        }
        if (thresArr.length > 0) {
          marking = [];
          thresArr.forEach((t, i) => {
            item = {
              name: 'targetTrend',
              valueFormatted: t,
              color: '#c8c8c8',
              yaxis: {
                from: t,
                to: t,
              },
              lineWidth: 2,
              thresColorMap: [],
            };
            if (ctrl.panel.trendMode === 'bar') {
              item.thresColorMap = ctrl.panel.trend.barColor;
            }
            marking.push(item);
          });
        }

        if (trendThresData) {
          if (trendThresData.valueFormatted) {
            marking = [];
            item = {
              name: 'targetTrend',
              valueFormatted: trendThresData.valueFormatted,
              color: '#c8c8c8',
              yaxis: {
                from: trendThresData.value,
                to: trendThresData.value,
              },
              lineWidth: 2,
              thresColorMap: [],
            };
            if (ctrl.panel.trendMode === 'bar') {
              item.thresColorMap = ctrl.panel.trend.barColor;
            }
            marking.push(item);
          } else {
            if (trendThresData[0] && trendThresData[0][0]) {
              dataArr = trendThresData[0][0].split(',').map(strVale => {
                return Number(strVale.trim());
              });
              marking = [];
              dataArr.forEach((d, i) => {
                item = {
                  name: 'targetTrend',
                  valueFormatted: d,
                  color: '#c8c8c8',
                  yaxis: {
                    from: d,
                    to: d,
                  },
                  lineWidth: 2,
                  thresColorMap: [],
                };
                if (ctrl.panel.trendMode === 'bar') {
                  item.thresColorMap = ctrl.panel.trend.barColor;
                }
                marking.push(item);
              });
            }
          }
        }
      }
      return marking;
    }

    function addTrend() {
      //elem flex
      if (ctrl.data['trendData'] || ctrl.data['trendThresData']) {
      } else {
        return;
      }
      ctrl.setSpaceCss(elem);
      elem.find('.indicatorsBoxFlex').css('flex', '0');
      elem.find('.indicatorsBoxFlex').css('padding', '0');
      elem.find('.indicatorSplitFlex').css('border-right', '2px dashed transparent');
      // empty
      const trendPanel = elem.find('.trend-panel');
      trendPanel.html('');

      const trendData = ctrl.data['trendData'];
      const trendThresData = ctrl.data['trendThresData'];
      let elemWidth = elem.width();
      let boxFlexWidth = elem.find('.indicatorsBoxFlex').width();
      let depth = 20;
      if (elemWidth / boxFlexWidth < 3.5 && elemWidth / boxFlexWidth > 3) {
        depth = 10;
      } else if (elemWidth / boxFlexWidth < 3) {
        depth = 2;
      }
      const width = elemWidth - boxFlexWidth - depth;
      let actualWidth = width * 85 / 100;
      if (elemWidth / boxFlexWidth < 3.5 && elemWidth / boxFlexWidth > 3) {
        actualWidth = width;
      } else if (elemWidth / boxFlexWidth < 3) {
        actualWidth = width;
      }
      const height = ctrl.height;
      trendPanel
        .width(actualWidth)
        .height(height)
        .css('position', 'relative');

      const plotCanvas = $('<div></div>');
      const plotCss: any = {};

      const ticks = width / 100;
      const min = _.isUndefined(ctrl.range.from) ? null : ctrl.range.from.valueOf();
      const max = _.isUndefined(ctrl.range.to) ? null : ctrl.range.to.valueOf();

      let options;
      let plotSeries;
      if (ctrl.panel.trendMode === 'graph' || ctrl.panel.trendMode === 'bar') {
        plotCss.position = 'absolute';
        plotCss.width = actualWidth + 'px';
        plotCss.height = height + 'px';
        plotCss.top = '50%';
        plotCss.left = '50%';
        plotCss.transform = 'translate(-50%, -50%)';
        plotCanvas.css(plotCss);
        elem.find('.trend-panel').append(plotCanvas);
        options = {
          legend: {show: false},
          series: {
            color: 'rgb(22, 195, 16)',
            lines: {
              show: ctrl.panel.trendMode === 'graph' ? true : false,
              fill: 1,
              lineWidth: 2,
              fillColor: {
                colors: [
                  {
                    opacity: 0,
                  },
                  {
                    opacity: 0.4,
                  },
                ],
              },
              zero: false,
            },
            bars: {
              show: ctrl.panel.trendMode === 'bar' ? true : false,
              fill: 1,
              barWidth: trendData.timeStep / 1.5 / 10 * ctrl.panel.trend.barWidth,
              zero: false,
              lineWidth: 1,
              align: 'left',
            },
          },
          yaxis: {
            show: true,
            font: {
              size: '14',
              lineHeight: '30',
              color: '#c8c8c8',
              family: 'Microsoft JhengHei',
              weight: 'bold',
            },
          },
          xaxis: {
            show: true,
            mode: 'time',
            min: min,
            max: max,
            format: 'Autoscale',
            format1: 'Autoscale',
            timezone: ctrl.dashboard.getTimezone(),
            timeformat: ctrl.time_format(ticks, min, max, ctrl.panel.trend.formatX),
            font: {
              size: '12',
              // lineHeight: '30',
              color: '#999999',
              family: 'Microsoft JhengHei',
              weight: 'normal',
            },
          },
          grid: {
            hoverable: false,
            show: true,
            borderColor: '#999999',
            markings: [],
          },
          name: 'indicator',
          fillDirection: ctrl.panel.trend.fillDirection,
          devide: ctrl.panel.trend.divide,
        };
        let targetTrendInfo = generateMarkings(trendThresData);
        options.grid.markings = options.grid.markings.concat(targetTrendInfo);
        plotSeries = {
          data: trendData.flotpairs,
          color: ctrl.panel.trend.lineColor,
        };
      } else if (ctrl.panel.trendMode === 'gauge') {
        elem.find('.trend-panel').css('display', 'table');
        const dimension = Math.min(actualWidth, height * 1.12);
        const gaugeWidth = Math.min(dimension / 6, 60) / 2 / 1.1;
        const thresholdMarkersWidth = gaugeWidth / 5;
        const plotCss = {
          top: '5px',
          margin: 'auto',
          position: 'relative',
          height: height * 0.9 + 'px',
          width: dimension * 1.2 + 'px',
        };
        if (dimension * 1.2 > elemWidth - boxFlexWidth - depth) {
          plotCss.width = dimension - 8 + 'px';
        }
        plotCanvas.css(plotCss);
        elem.find('.trend-panel').append(plotCanvas);

        // thresehold
        let Thresholds = ''; //input single value
        let thresholdArr = []; //[]
        let thresholds = []; // option
        const v = ctrl.panel.trend.maxValue;
        let lastV = -Infinity;
        let colorNumber = ctrl.panel.trend.gaugeColor.length;
        let colorIndex = 0;
        if (trendThresData || ctrl.panel.trend.fillThres) {
          Thresholds = trendThresData
            ? trendThresData.value + ''
            : ctrl.panel.trend.fillThres;
        }
        thresholdArr = Thresholds.split(',').map(strVale => {
          return Number(strVale.trim());
        });
        if (Thresholds === '') {
          thresholds.push({
            value: 0,
            color: ctrl.panel.trend.gaugeColor[0],
          });
        } else {
          thresholdArr.every(tv => {
            if (tv < v && tv > lastV && colorNumber-- > 1) {
              thresholds.push({
                value: tv,
                color: ctrl.panel.trend.gaugeColor[colorIndex++],
                display: trendThresData
                  ? trendThresData.valueFormatted
                  : ctrl.panel.trend.fillThres,
              });
              lastV = tv;
              return true;
            }
            return false;
          });
        }
        thresholds.push({
          value: v,
          color: ctrl.panel.trend.gaugeColor[colorIndex],
        });

        options = {
          series: {
            gauges: {
              gauge: {
                min: ctrl.panel.trend.minValue,
                max: ctrl.panel.trend.maxValue,
                background: {color: 'rgb(78,78,79)'},
                border: {color: null},
                shadow: {show: false},
                width: gaugeWidth,
              },
              frame: {show: false},
              label: {show: false},
              layout: {margin: 0, thresholdWidth: 0},
              cell: {border: {width: 0}},
              threshold: {
                values: thresholds,
                label: {
                  show: true,
                  thresLabel: Thresholds !== '' ? true : false,
                  margin: thresholdMarkersWidth + 1,
                  font: {
                    type: 'singlestat',
                    isVw: false,
                    size: 14,
                    family: 'Microsoft JhengHei',
                  },
                  color: '#ffffff',
                },
                show: false, //marker
                width: 0,
              },
              value: {
                color: '#ffffff',
                font: {
                  type: 'singlestat',
                  isVw: true,
                  size: 42,
                  family: '"Helvetica Neue", Helvetica, Arial, sans-serif',
                },
              },
              show: true,
            },
          },
          name: 'indicator-gauge',
        };

        plotSeries = {
          data: [[0, trendData.value]],
        };
      }

      try {
        ($ as any).plot(plotCanvas, [plotSeries], options);
      } catch (e) {
        //console.log(e);
      }
    }

    function getAllTargetHtml(currentConfig, data, targetNameFontSize, targetNameColor) {
      let body = '';
      let targetValue;
      if (currentConfig.target.fillValue === '' && !data.valueFormattedTarget) {
        targetValue = 'N/A';
      }
      if (currentConfig.target.fillValue !== '') {
        targetValue = currentConfig.target.fillValue;
      }
      if (data.valueFormattedTarget) {
        targetValue = data.valueFormattedTarget && (!isNaN(data.valueFormattedTarget)) ?
          data.valueFormattedTarget : data.valueTarget;
      }
      body +=
        '<div class="topTarget basicIndicatorFont" style="font-size:' +
        targetNameFontSize +
        ';color:' +
        targetNameColor +
        '">' +
        currentConfig.target.name +
        '</div>';
      // target_bottom
      if (
        currentConfig.target.position === 'under' &&
        currentConfig.target.name === '' &&
        targetValue === 'N/A' &&
        currentConfig.target.preAndPostfix.postfix === '' &&
        currentConfig.target.preAndPostfix.prefix === ''
      ) {
        body += '<div class="bottomTarget">';
      } else if (currentConfig.target.position === 'under') {
        body += '&nbsp;<div class="bottomTarget">';
      } else {
        body += '<div class="bottomTarget">';
      }
      if (currentConfig && currentConfig.target.preAndPostfix.prefix !== '') {
        const preFontSize = getFontSize(currentConfig.target.preAndPostfix.preFontSize);
        const preColor = currentConfig.target.preAndPostfix.preColor;
        body +=
          '<span class="basicIndicatorFont leftpre" style="font-size:' +
          preFontSize +
          ';color:' +
          preColor +
          '">' +
          currentConfig.target.preAndPostfix.prefix +
          '</span>';
      }
      const targetFontSize = getFontSize(currentConfig.target.valueFontSize);
      const targetValueColor = currentConfig.target.valueColor;
      if (
        currentConfig.target.name === '' &&
        targetValue === 'N/A' &&
        currentConfig.target.preAndPostfix.postfix === '' &&
        currentConfig.target.preAndPostfix.prefix === ''
      ) {
        // body += '<span class="basicIndicatorFont targetValue" style="font-size:' + targetFontSize + ';color:'
        // + targetValueColor + ';visibility: hidden">'+ targetValue + '</span>';
      } else if (currentConfig.target.name !== '' && targetValue === 'N/A') {
        body +=
          '<span class="basicIndicatorFont targetValue" style="font-size:' +
          targetFontSize +
          ';color:' +
          targetValueColor +
          '">' +
          targetValue +
          '</span>';
      } else if (
        (currentConfig.target.preAndPostfix.postfix !== '' ||
          currentConfig.target.preAndPostfix.prefix !== '') &&
        targetValue === 'N/A'
      ) {
      } else {
        body +=
          '<span class="basicIndicatorFont targetValue" style="font-size:' +
          targetFontSize +
          ';color:' +
          targetValueColor +
          '">' +
          targetValue +
          '</span>';
      }

      if (currentConfig && currentConfig.target.preAndPostfix.postfix !== '') {
        const postFontSize = getFontSize(currentConfig.target.preAndPostfix.postFontSize);
        const postColor = currentConfig.target.preAndPostfix.postColor;
        body +=
          '<span class="basicIndicatorFont leftpre" style="font-size:' +
          postFontSize +
          ';color:' +
          postColor +
          '">' +
          currentConfig.target.preAndPostfix.postfix +
          '</span>';
      }
      body += '</div>';
      console.log(body);
      if (currentConfig.target.position === 'under') {
        body = body.replace(/div/g, 'span');
      }
      console.log(body);
      return body;
    }

    function getRightTargetHtml(currentConfig, data, position) {
      let body;
      if (position === 'right') {
        body = '<div class="rightTarget">';
      } else {
        // body = '<div class="rightTarget" style="position:relative;top:-10px;">';
        body = '<div class="rightTarget" style="">';
      }
      const targetNameFontSize = getFontSize(currentConfig.target.nameFontSize);
      const targetNameColor = currentConfig.target.nameColor;
      // target_top
      let targetAllStr = getAllTargetHtml(
        currentConfig,
        data,
        targetNameFontSize,
        targetNameColor
      );
      body += targetAllStr + '</div>';
      return body;
    }

    function addBorderRight() {
      let indicatorSplit = elem.find('.indicatorSplitFlex');
      if (indicatorSplit.length >= 2) {
        for (let i = 0; i < indicatorSplit.length - 1; i++) {
          $(indicatorSplit[i]).addClass('boderRight');
        }
      }
    }

    function getFontSize(fontSize) {
      let mobileApp = '';
      if (this.dashboard && this.dashboard.meta) {
        if (this.dashboard.meta.isPc === false) {
          mobileApp = 'mobile';
        }
      }
      const isVw = panel.adjustableFontSize;
      return ChangeFont.fontSizeChange(isVw, fontSize, mobileApp);
    }

    function getIndicatorConfigCount() {
      return ctrl.panel.indicatorsConfigs.length;
    }

    function getIndicatorsHtml() {
      // let body = '<div class="indicatorsBoxFlex">';
      elem.find('.indicatorsBoxFlex').css('flex', '');
      let body = '';
      const indicatorWidth = 100 / getIndicatorConfigCount();
      if (getIndicatorConfigCount() === 0 && panel.currentMode === 'indicators') {
        body +=
          '<span class="noData">Please add item in Indicatiors Setting.</span></div>';
        return body;
      }
      const {indicatorsHeading} = panel;
      const needName = panel.currentMode === 'reference' && indicatorsHeading.name;
      if (needName) {
        const {name, fontSize, color} = indicatorsHeading;
        body += `<div class="indicatorsBoxContainer"><div class="indicatorsBoxHeader"
        style="font-size: ${getFontSize(
          fontSize
        )}; color: ${color}">${name}</div><div class="indicatorsBoxContent">`;
      }
      const defalutTextColor = config.bootData.user.lightTheme ? '#000000' : '#FFFFFF';
      ctrl.data.forEach((data, i) => {
        // if (data.value) {
        const currentConfig = panel.indicatorsConfigs[i];
        body += `<div class="indicatorSplitFlex" ${
          panel.currentMode === 'indicators' ? `style="width:${indicatorWidth}%;justify-content:${panel.indicatorPosition}"` : ''
        }>`;
        // body += '<div class="indicatorValueFlex"><div class="centerValue" style="height:' + (ctrl.height - 20) + 'px">';
        body += '<div class="indicatorValueFlex">';
        const {on, type} = currentConfig.value.thresholds;
        const {colorMaps, valueMaps} = currentConfig;
        const {valueThres, textThres, colorMap, value} = data;
        const valueThresValid =
          valueThres && valueThres.every(n => !isNaN(n)) && valueThres.length === 2;
        // 开启 thresholds number 模式
        if (
          _.isNumber(value) &&
          on &&
          type === 'number' &&
          valueThresValid &&
          textThres.length === 3
        ) {
          const displayIndex = value < valueThres[0] ? 0 : value > valueThres[1] ? 2 : 1;
          body += `<div class="thres-status" style="color:${
            colorMap[displayIndex]
          }; border-color:${colorMap[displayIndex]};
          background-color:${colorMap[displayIndex] + '33'};font-size:${
            currentConfig.value.fontSize
          }">
            ${textThres[displayIndex]}
          </div>`;
          body += '</div></div>';
        } else if (
          _.isString(value) &&
          on &&
          type === 'string' &&
          valueMaps.length >= 1
        ) {
          const displayText =
            (valueMaps.find(map => map.value === value) || {}).text || value;
          const displayColor =
            (colorMaps.find(map => map.value === value) || {}).text || defalutTextColor;
          body += `<div class="thres-status" style="color:${displayColor}; border-color:${displayColor};
            background-color:${displayColor + '33'};font-size:${
            currentConfig.value.fontSize
          }">
              ${displayText}
            </div>`;
          body += '</div></div>';
        } else {
          body += '<div class="centerValue">';
          //top
          if (currentConfig && currentConfig.subtitle.name !== '') {
            const subTitleFontSize = getFontSize(currentConfig.subtitle.fontSize);
            body +=
              '<div class="subtitleFont" style="font-size:' +
              subTitleFontSize +
              ';color:' +
              currentConfig.subtitle.color +
              '">' +
              currentConfig.subtitle.name +
              '</div>';
          }
          // bottom
          // color
          let dataVlue;
          // if (_.isNumber(data.value)) {
          if (data.value) {
            dataVlue = data.valueFormatted && (!isNaN(data.valueFormatted)) ? data.valueFormatted : data.value;
          } else {
            dataVlue = 'N/A';
          }

          let valueColor = defalutTextColor;
          if (currentConfig.value.thresholds.on) {
            valueColor =
              getColoringThresholds(data, data.value, 'value') || defalutTextColor;
          }

          if (currentConfig.target.position === 'right') {
            body += '<div class="bottomValue"><div class="leftValue">';
          } else {
            body += '<div class="bottomLeftValue"><div class="leftValue">';
          }
          if (currentConfig && currentConfig.prefix.name !== '') {
            const prefixFontSize = getFontSize(currentConfig.prefix.fontSize);
            const prefixColor = currentConfig.prefix.applyValueColor
              ? valueColor
              : defalutTextColor;
            body +=
              '<span class="basicIndicatorFont" style="font-size:' +
              prefixFontSize +
              ';color:' +
              prefixColor +
              ';">' +
              currentConfig.prefix.name +
              '</span>';
          }
          //value

          const valueFontSize = getFontSize(currentConfig.value.fontSize);
          body +=
            '<span class="valueIndicatorFont" style="font-size:' +
            valueFontSize +
            ';color:' +
            valueColor +
            ';">' +
            dataVlue +
            '</span>';

          if (ctrl.dataType === 'timeseries') {
            if (
              (currentConfig && currentConfig.postfix.name !== '') ||
              (currentConfig && currentConfig.postfix.selected !== '')
            ) {
              const postName =
                currentConfig.postfix.selected !== ''
                  ? data.postFixName
                  : currentConfig.postfix.name;
              const postfixFontSize = getFontSize(currentConfig.postfix.fontSize);
              const postfixColor = currentConfig.postfix.applyValueColor
                ? valueColor
                : defalutTextColor;
              body +=
                '<span class="basicIndicatorFont" style="font-size:' +
                postfixFontSize +
                ';color:' +
                postfixColor +
                ';">' +
                postName +
                '</span>';
            }
          }

          if (ctrl.dataType === 'table') {
            if (
              (currentConfig && currentConfig.postfix.name !== '') ||
              (currentConfig && data.postFixName)
            ) {
              const postName = data.postFixName
                ? data.postFixName
                : currentConfig.postfix.name;
              const postfixFontSize = getFontSize(currentConfig.postfix.fontSize);
              const postfixColor = currentConfig.postfix.applyValueColor
                ? valueColor
                : '#ffffff';
              body +=
                '<span class="basicIndicatorFont" style="font-size:' +
                postfixFontSize +
                ';color:' +
                postfixColor +
                ';">' +
                postName +
                '</span>';
            }
          }
          body += '</div>';

          //bottom right target
          // body += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
          body += '<div class="centerSpace"></div>';
          //left rigth
          if (currentConfig.target.position === 'right') {
            let rightTargetHtml = getRightTargetHtml(currentConfig, data, 'right');
            body += rightTargetHtml;
          }
          //rightTarget part
          body += '</div>';
          if (currentConfig.target.position === 'under') {
            let rightTargetHtml = getRightTargetHtml(currentConfig, data, 'under');
            body += rightTargetHtml;
          }
          //bottomValuet part
          body += '</div></div></div>';
        }
      });
      if (needName) {
        body += `</div></div>`;
      }
      // body += '</div>';

      return body;
    }

    function getColoringThresholds(data, value, type) {
      if (!_.isFinite(value)) {
        return null;
      }

      let thresholds: any;

      let rcolor: any;

      if (type === 'value') {
        thresholds = data.valueThres;
        rcolor = data.colorMap;
      }

      for (let i = thresholds.length; i > 0; i--) {
        if (value >= thresholds[i - 1]) {
          return rcolor[i];
        }
      }

      return _.first(rcolor);
    }

    function getThres() {
      panel.indicatorsConfigs.forEach((ic, index) => {
        const valueThresConfig = ic.value;
        let valueThresStr;
        if (ctrl.dataType === 'timeseries') {
          if (valueThresConfig.thresholds.selected !== '') {
            valueThresStr = data[index].thresholdsSelectStr;
          } else {
            valueThresStr = valueThresConfig.thresholds.fill;
          }
        }
        if (ctrl.dataType === 'table') {
          if (
            valueThresConfig.thresholds.selectedQuery !== '' &&
            valueThresConfig.thresholds.selectedCol !== ''
          ) {
            valueThresStr = data[index].thresholdsSelectStr;
          } else {
            valueThresStr = valueThresConfig.thresholds.fill;
          }
        }
        const valueThres = templateSrv.replace(
          valueThresStr,
          panel.scopedVars,
          'donotEscapeBrackets'
        );
        const textThres = templateSrv.replace(
          valueThresConfig.thresholds.display,
          panel.scopedVars,
          'donotEscapeBrackets'
        );
        if (data.length > 0) {
          if (valueThresConfig.thresholds.on) {
            data[index].valueThres = valueThres
              .split(',')
              .map(strVale => {
                return Number(strVale.trim());
              })
              .splice(0, 2);
            data[index].colorMap = valueThresConfig.colors;
            data[index].textThres = textThres.split(',').splice(0, 3);
          } else {
            data[index].valueThres = [];
            data[index].colorMap = [];
            data[index].textThres = [];
          }
        }
      });
    }

    function setThres() {}

    this.events.on('render', () => {
      render();
      ctrl.renderingCompleted();
    });
  }
}

export {PaneCtrl, PaneCtrl as PanelCtrl};
