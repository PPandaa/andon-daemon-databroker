///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import $ from 'jquery';
import kbn from 'app/core/utils/kbn';
import {MetricsPanelCtrl, loadPluginCss} from 'app/plugins/sdk';
import ChangeFont from 'app/core/utils/fontsize';
import TimeSeries from 'app/core/time_series';
import config from 'app/core/config';
import {panelDefaults} from './module';

// System.import('plugins/advantech-indicator-panel/css/default.css' + '!css');
loadPluginCss({
  dark: 'plugins/advantech-indicator-panel/css/dark.css',
  light: 'plugins/advantech-indicator-panel/css/light.css',
});

export class ReferenceCtrl {
  panel: any;
  dashboard: any;
  panelCtrl: any;
  activeReferenceIndex: any;
  activeRowIndex: any;
  positionOptions = [
    {label: 'top', value: 'start'},
    {label: 'center', value: 'center'},
    {label: 'bottom', value: 'flex-end'},
  ];
  /** @ngInject */
  constructor($scope) {
    $scope.referEditor = this;
    this.panelCtrl = $scope.ctrl;
    this.panel = this.panelCtrl.panel;
    this.activeReferenceIndex = this.panelCtrl.activeReferenceIndex;
    this.activeRowIndex = this.panelCtrl.activeRowIndex;
  }

  onValueSelectChange() {
    this.refresh();
  }

  addTableConfig() {
    const tableConfig = panelDefaults.referenceConfigs[0];
    this.panel.referenceConfigs.push(tableConfig);
    this.refresh();
  }

  addReferRow(rconfigIndex) {
    const row = {
      label: '',
      selected: '',
    };
    this.panel.referenceConfigs[rconfigIndex].tbody.push(row);
    this.render();
  }

  removeTableConfig(rconfig) {
    this.panel.referenceConfigs = _.without(this.panel.referenceConfigs, rconfig);
    this.activeReferenceIndex = this.panel.referenceConfigs.length - 1;
  }

  removeRow(rconfigIndex, row) {
    let tbodyRows = this.panel.referenceConfigs[rconfigIndex].tbody;
    const rowRes = _.without(tbodyRows, row);
    this.panel.referenceConfigs[rconfigIndex].tbody = rowRes;
    this.activeRowIndex = this.panel.referenceConfigs[rconfigIndex].tbody.length - 1;
    this.panelCtrl.refresh();
  }

  render() {
    this.panelCtrl.render();
  }

  refresh() {
    this.panelCtrl.refresh();
  }
}

/** @ngInject */
export function reference() {
  'use strict';
  return {
    restrict: 'E',
    scope: true,
    templateUrl: 'public/plugins/advantech-indicator-panel/partials/reference.html',
    controller: ReferenceCtrl,
  };
}
