declare module 'app/core/utils/fontsize' {
  var ChangeFont: any;
  export default ChangeFont;
}

declare module 'app/core/time_series' {
  var TimeSeries: any;
  export default TimeSeries;
}

// declare module 'jquery.marquee' {
//     var Limarquee: any;
//     export default Limarquee;
// }
