# Grafana Pane Panel

## Building

This plugin relies on Grunt/NPM/Bower, typical build sequence:

```
npm install
bower install
grunt
```

For development, you can run:

```
grunt watch
```

The code will be parsed then copied into "dist" if "jslint" passes without errors.

### Docker Support

A docker-compose.yml file is include for easy development and testing, just run

```
docker-compose up
```

Then browse to http://localhost:3000

## External Dependencies

* Grafana 3.x/4.x/5.x

## Build Dependencies

* npm
* bower
* grunt

#### Changelog

| Version | Changes                                                                              |
| ------- | ------------------------------------------------------------------------------------ |
| 1.0.1   | first release                                                                        