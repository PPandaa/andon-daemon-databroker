# Changelog

All notable changes to this project will be documented in this file.
<<<<<<< HEAD

=======

> > > > > > > ca7d7978a9eeea7f60ac1ef12dd1a26657eefbbe

## [1.0.16] - Apr 27,2021

*  left bug

## [1.0.15] - Apr 27,2021

* indicator left

## [1.0.14] - Apr 26,2021

* value string

## [1.0.13] - Apr 26,2021

* flow issue

## [1.0.12] - Apr 23,2021

* refer table

## [1.0.11] - Apr 22,2021

* indicator refer table

## [1.0.10] - Apr 21,2021

* indicator table bug

## [1.0.9] - Apr 20,2021

* indicator table

## [1.0.8] - Apr 20,2021

* reference

## [1.0.7] - Apr 13,2021

* 3.0 requirement

## [1.0.6] - Apr 04,2021

* gauge adjust

## [1.0.5] - Mar 31,2021

* graph devide

## [1.0.4] - Mar 30,2021

* gauge bar trend

## [1.0.3] - Mar 17,2021

* graph trend

## [1.0.2] - Mar 08,2021

* target position

## [1.0.1] - Feb 24,2021

* first release
